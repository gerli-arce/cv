<?php

use Illuminate\Support\Facades\Route;

// Ruta catch-all para React Router
Route::get('/{any?}', function () {
    return view('app');
})->where('any', '^(?!api).*$');
