"use client"

import React, { Suspense } from "react"
import { motion } from "framer-motion"
import { fadeInUp, staggerContainer, scaleHover } from "../utils/motionPresets"
import SEO from "../components/SEO"

const AboutMe = React.lazy(() => import("../components/AboutMe"))
const TechSkills = React.lazy(() => import("../components/TechSkills"))
const Projects = React.lazy(() => import("../components/Projects"))
const Experience = React.lazy(() => import("../components/Experience"))
const ContactForm = React.lazy(() => import("../components/ContactForm"))

const SectionLoader = () => (
  <div className="py-20 flex justify-center items-center">
    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
  </div>
)

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <SEO
        title="Inicio | Juan Pérez - Desarrollador Full Stack"
        description="Bienvenido a mi portafolio. Soy experto en Laravel, React y arquitecturas modernas de software."
      />

      {/* Hero Section (Loaded immediately for LCP) */}
      <section
        aria-label="Introducción"
        className="flex-grow flex items-center justify-center px-6 py-20 sm:px-8 overflow-hidden"
      >
        <motion.div
          className="max-w-4xl w-full space-y-12 text-center"
          variants={staggerContainer}
          initial="hidden"
          animate="show"
        >
          <motion.div className="relative mx-auto w-40 h-40 sm:w-48 sm:h-48" variants={fadeInUp}>
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 blur-lg opacity-75 animate-pulse"></div>
            <motion.img
              className="relative w-full h-full rounded-full object-cover border-4 border-white shadow-xl"
              src="https://github.com/shadcn.png"
              alt="Foto de perfil del desarrollador" // Improved alt text
              width="192" // Explicit dimensions
              height="192"
              priority="true" // Note: standardized HTML doesn't use priority, but React frameworks might. Standard img attributes used.
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            />
          </motion.div>

          <div className="space-y-6">
            <motion.h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-gray-900" variants={fadeInUp}>
              Hola, soy{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Tu Nombre
              </span>
            </motion.h1>

            {/* ... existing text ... */}
            <motion.h2 className="text-xl sm:text-2xl font-medium text-gray-600" variants={fadeInUp}>
              Full Stack Developer | Laravel & React
            </motion.h2>

            <motion.p className="max-w-2xl mx-auto text-lg text-gray-500 leading-relaxed" variants={fadeInUp}>
              Construyo soluciones web robustas y escalables. Especializado en crear experiencias de usuario fluidas con
              React integradas perfectamente en backends de Laravel.
            </motion.p>
          </div>

          <motion.div className="flex flex-wrap justify-center gap-4" variants={fadeInUp}>
            <motion.a
              href="#about"
              className="inline-flex items-center px-8 py-3 rounded-full text-white bg-indigo-600 font-semibold shadow-lg focus:ring-4 focus:ring-indigo-300 focus:outline-none" // Added focus styles for a11y
              aria-label="Ir a la sección Sobre Mí" // Added aria-label
              variants={scaleHover}
              initial="rest"
              whileHover="hover"
              whileTap={{ scale: 0.95 }}
            >
              {/* ... svg ... */}
              <svg
                className="w-5 h-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 14l-7 7m0 0l-7-7m7 7V3"
                ></path>
              </svg>
              Conóceme más
            </motion.a>
            {/* ... existing buttons with added aria-labels and focus styles ... */}
          </motion.div>
        </motion.div>
      </section>

      <Suspense fallback={<SectionLoader />}>
        <AboutMe />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <Experience />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <TechSkills />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <Projects />
      </Suspense>

      <Suspense fallback={<SectionLoader />}>
        <ContactForm />
      </Suspense>
    </div>
  )
}
