import { Link } from "react-router-dom"

const Layout = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen font-sans">
      <header className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="text-2xl font-heading font-bold text-indigo-600">
            DevPortfolio
          </Link>
          <nav className="hidden md:flex space-x-8">
            <a href="#about" className="text-gray-600 hover:text-indigo-600 transition-colors">
              Sobre mí
            </a>
            <a href="#projects" className="text-gray-600 hover:text-indigo-600 transition-colors">
              Proyectos
            </a>
            <a href="#contact" className="text-gray-600 hover:text-indigo-600 transition-colors">
              Contacto
            </a>
          </nav>
        </div>
      </header>

      <main className="flex-grow pt-20">{children}</main>

      <footer className="bg-slate-900 text-white py-8 text-center">
        <p>&copy; {new Date().getFullYear()} Tu Nombre. Laravel 11 + React + Vite.</p>
      </footer>
    </div>
  )
}

export default Layout
