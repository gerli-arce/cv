"use client"

// ... existing imports ...
import { motion } from "framer-motion"
import { Github, ExternalLink } from "lucide-react"
import { fadeInUp, staggerContainer } from "../utils/motionPresets"

const projects = [
  {
    id: 1,
    title: "E-Commerce Dashboard",
    description: "Panel de administración completo...",
    image: "/general-data-dashboard.png",
    tags: ["Laravel", "React", "Inertia", "Tailwind"],
    demoUrl: "#",
    codeUrl: "#",
  },
  // ... existing projects ...
  {
    id: 2,
    title: "Task Management App",
    description: "App colaborativa tipo Kanban...",
    image: "/kanban-board.png",
    tags: ["React", "Vite", "Firebase", "Redux"],
    demoUrl: "#",
    codeUrl: "#",
  },
  {
    id: 3,
    title: "Real Estate Platform",
    description: "Plataforma inmobiliaria...",
    image: "/real-estate.jpg",
    tags: ["Laravel", "MySQL", "Vue.js", "Bootstrap"],
    demoUrl: "#",
    codeUrl: "#",
  },
]

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-gray-50" aria-labelledby="projects-title">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <motion.div
          className="text-center mb-16"
          variants={fadeInUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <h2 id="projects-title" className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Proyectos Destacados
          </h2>
          {/* ... existing divider ... */}
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Una selección de mis trabajos más recientes en desarrollo Full Stack.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          {projects.map((project) => (
            <motion.div
              key={project.id}
              className="group bg-white rounded-xl overflow-hidden border border-gray-100 shadow-lg flex flex-col h-full"
              variants={fadeInUp}
              whileHover={{
                scale: 1.02,
                boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="relative aspect-video overflow-hidden bg-gray-200">
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 flex items-center justify-center focus-within:opacity-100">
                  <span className="text-white font-semibold tracking-wider border-2 border-white px-4 py-2 rounded-lg transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    Ver Proyecto
                  </span>
                </div>

                <motion.img
                  src={project.image || "/placeholder.svg"}
                  alt={`Captura de pantalla del proyecto ${project.title}`}
                  className="w-full h-full object-cover"
                  loading="lazy"
                  width="600"
                  height="400"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                />
              </div>

              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed line-clamp-3 flex-grow">
                  {project.description}
                </p>

                {/* ... existing tags ... */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-2.5 py-1 text-xs font-semibold text-indigo-600 bg-indigo-50 rounded-md"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex gap-3 pt-4 border-t border-gray-100 mt-auto">
                  <a
                    href={project.demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-300 outline-none transition-all"
                    aria-label={`Ver demostración en vivo de ${project.title}`}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver Demo
                  </a>
                  <a
                    href={project.codeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:text-indigo-600 hover:border-indigo-200 focus:ring-4 focus:ring-gray-100 outline-none transition-all"
                    aria-label={`Ver código fuente de ${project.title} en GitHub`}
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Código
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
