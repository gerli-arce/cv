"use client"

import { motion } from "framer-motion"
import { Server, Database, Terminal, Layout } from "lucide-react"
import { fadeInUp, staggerContainer } from "../utils/motionPresets"

const SkillCategory = ({ title, icon: Icon, skills, colorClass }) => (
  <motion.div
    className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 group"
    variants={fadeInUp}
    whileHover={{ y: -5, boxShadow: "0 10px 30px -10px rgba(0,0,0,0.1)" }}
  >
    <div className="flex items-center gap-3 mb-6">
      <div className={`p-3 rounded-xl ${colorClass} group-hover:scale-110 transition-transform duration-300`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    </div>

    <div className="flex flex-wrap gap-2">
      {skills.map((skill, index) => (
        <span
          key={index}
          className="px-3 py-1.5 bg-gray-50 text-gray-600 text-sm font-medium rounded-lg border border-gray-100 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-colors duration-200 cursor-default select-none"
        >
          {skill}
        </span>
      ))}
    </div>
  </motion.div>
)

export default function TechSkills() {
  // ... existing categories array ...
  const categories = [
    {
      title: "Frontend Development",
      icon: Layout,
      colorClass: "bg-gradient-to-br from-blue-500 to-cyan-400",
      skills: ["React", "Vite", "Tailwind CSS", "JavaScript (ES6+)", "HTML5", "CSS3"],
    },
    {
      title: "Backend Development",
      icon: Server,
      colorClass: "bg-gradient-to-br from-red-500 to-orange-400",
      skills: ["Laravel", "PHP 8+", "Node.js", "RESTful APIs", "Express"],
    },
    {
      title: "Database & Architecture",
      icon: Database,
      colorClass: "bg-gradient-to-br from-emerald-500 to-teal-400",
      skills: ["MySQL", "PostgreSQL", "Eloquent ORM", "Database Design"],
    },
    {
      title: "DevOps & Tools",
      icon: Terminal,
      colorClass: "bg-gradient-to-br from-slate-700 to-slate-500",
      skills: ["Git", "GitHub", "Docker", "Linux (Bash)", "Composer", "NPM/Yarn"],
    },
  ]

  return (
    <section className="py-20 bg-gray-50" id="skills">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          variants={fadeInUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Arsenal Tecnológico</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-600 text-lg">
            Un conjunto de herramientas modernas seleccionadas para construir aplicaciones web rápidas, escalables y
            robustas.
          </p>
        </motion.div>

        {/* Grid de Categorías */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          {categories.map((category, index) => (
            <SkillCategory key={index} {...category} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}
