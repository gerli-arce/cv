"use client"

import { motion } from "framer-motion"
import { Briefcase, Calendar } from "lucide-react"
import { fadeInUp, staggerContainer } from "../utils/motionPresets"

const experiences = [
  {
    id: 1,
    role: "Senior Full Stack Developer",
    company: "Tech Solutions Inc.",
    period: "2022 - Presente",
    description:
      "Liderando el desarrollo de aplicaciones empresariales usando Laravel y React. Implementación de arquitectura hexagonal y CI/CD.",
    technologies: ["Laravel", "React", "AWS", "Docker"],
  },
  {
    id: 2,
    role: "Backend Developer",
    company: "Digital Agency",
    period: "2020 - 2022",
    description:
      "Desarrollo de APIs RESTful de alto rendimiento y optimización de consultas SQL para clientes internacionales.",
    technologies: ["PHP", "MySQL", "Redis", "Symfony"],
  },
  {
    id: 3,
    role: "Frontend Developer",
    company: "StartUp Creative",
    period: "2019 - 2020",
    description: "Creación de interfaces de usuario interactivas y responsive. Migración de sistemas legacy a React.",
    technologies: ["React", "SASS", "JavaScript", "Figma"],
  },
]

export default function Experience() {
  return (
    <section className="py-20 bg-white" id="experience">
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        <motion.div
          className="text-center mb-16"
          variants={fadeInUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Experiencia Laboral</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full"></div>
        </motion.div>

        <motion.div
          className="space-y-12"
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          {experiences.map((exp) => (
            <motion.div key={exp.id} className="relative flex gap-6 md:gap-10" variants={fadeInUp}>
              {/* Timeline Line */}
              <div className="absolute left-[19px] top-0 bottom-0 w-0.5 bg-gray-200 last:bottom-auto last:h-full"></div>

              {/* Icon */}
              <div className="relative z-10 shrink-0 w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center border-4 border-white shadow-sm">
                <Briefcase className="w-5 h-5 text-indigo-600" />
              </div>

              {/* Content */}
              <div className="pb-12 last:pb-0 w-full">
                <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 hover:shadow-md transition-shadow duration-300">
                  <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{exp.role}</h3>
                      <p className="text-indigo-600 font-medium">{exp.company}</p>
                    </div>
                    <div className="flex items-center text-gray-500 text-sm font-medium bg-white px-3 py-1 rounded-full shadow-sm border border-gray-100">
                      <Calendar className="w-4 h-4 mr-2" />
                      {exp.period}
                    </div>
                  </div>

                  <p className="text-gray-600 mb-4 leading-relaxed">{exp.description}</p>

                  <div className="flex flex-wrap gap-2">
                    {exp.technologies.map((tech, index) => (
                      <span
                        key={index}
                        className="text-xs font-semibold text-gray-500 bg-white border border-gray-200 px-2 py-1 rounded-md"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
