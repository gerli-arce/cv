"use client"

import { useEffect } from "react"

export default function SEO({ title, description }) {
  useEffect(() => {
    // Actualizar título
    document.title = title

    // Actualizar meta description
    const metaDescription = document.querySelector('meta[name="description"]')
    if (metaDescription) {
      metaDescription.setAttribute("content", description)
    } else {
      const meta = document.createElement("meta")
      meta.name = "description"
      meta.content = description
      document.head.appendChild(meta)
    }
  }, [title, description])

  return null
}
