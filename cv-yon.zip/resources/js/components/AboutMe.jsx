"use client"

import { motion } from "framer-motion"
import { fadeInUp, fadeInLeft, fadeInRight } from "../utils/motionPresets"

export default function AboutMe() {
  // ... existing data arrays (skills, milestones) ...
  const skills = [
    "Responsabilidad",
    "Proactividad",
    "Comunicación Efectiva",
    "Resolución de Problemas",
    "Trabajo en Equipo",
    "Aprendizaje Continuo",
  ]

  const milestones = [
    {
      year: "2021",
      title: "Inicios en Desarrollo Web",
      description: "Comencé mi camino aprendiendo HTML, CSS y JavaScript, creando mis primeros proyectos personales.",
    },
    {
      year: "2022",
      title: "Especialización en Laravel & React",
      description: "Profundicé en el ecosistema de Laravel y la creación de SPAs modernas con React y Vite.",
    },
    {
      year: "2024",
      title: "Desarrollador Full Stack",
      description:
        "Actualmente construyendo aplicaciones completas y escalables, integrando las mejores prácticas del sector.",
    },
  ]

  return (
    <section className="py-20 bg-white overflow-hidden" id="about">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          variants={fadeInUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Sobre mí</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Columna Izquierda: Presentación y Skills */}
          <motion.div
            className="space-y-8"
            variants={fadeInLeft}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="prose prose-lg text-gray-600">
              <p className="leading-relaxed">
                Soy un desarrollador apasionado por transformar ideas complejas en experiencias digitales elegantes y
                funcionales. Con un fuerte enfoque en el ecosistema{" "}
                <span className="font-semibold text-indigo-600">Laravel</span> y{" "}
                <span className="font-semibold text-indigo-600">React</span>, disfruto creando arquitecturas limpias y
                mantenibles.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Habilidades Personales</h3>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill, index) => (
                  <motion.span
                    key={index}
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-indigo-50 hover:text-indigo-700 cursor-default"
                    whileHover={{ scale: 1.05 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Columna Derecha: Timeline */}
          <motion.div
            className="bg-gray-50 p-8 rounded-2xl shadow-sm border border-gray-100"
            variants={fadeInRight}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-100px" }}
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              {/* ... existing svg ... */}
              <svg className="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                ></path>
              </svg>
              Mi Trayectoria
            </h3>

            <div className="relative pl-8 border-l-2 border-indigo-200 space-y-8">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={index}
                  className="relative"
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.2, duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  {/* Dot */}
                  <div className="absolute -left-[41px] top-0 w-6 h-6 bg-white border-4 border-indigo-600 rounded-full"></div>
                  {/* ... existing content ... */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-1">
                    <h4 className="text-lg font-bold text-gray-900">{milestone.title}</h4>
                    <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full mt-1 sm:mt-0 w-fit">
                      {milestone.year}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{milestone.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
