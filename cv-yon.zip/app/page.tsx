"use client"

import type React from "react"

import { ArrowDown, Github, Linkedin, ExternalLink, Send, Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { Server, Database, Terminal, Layout } from "lucide-react"
import { useState } from "react"

function AboutMe() {
  const skills = [
    "Responsabilidad",
    "Proactividad",
    "Comunicación Efectiva",
    "Resolución de Problemas",
    "Trabajo en Equipo",
    "Aprendizaje Continuo",
  ]

  const milestones = [
    {
      year: "2021",
      title: "Inicios en Desarrollo Web",
      description: "Comencé mi camino aprendiendo HTML, CSS y JavaScript, creando mis primeros proyectos personales.",
    },
    {
      year: "2022",
      title: "Especialización en Laravel & React",
      description: "Profundicé en el ecosistema de Laravel y la creación de SPAs modernas con React y Vite.",
    },
    {
      year: "2024",
      title: "Desarrollador Full Stack",
      description:
        "Actualmente construyendo aplicaciones completas y escalables, integrando las mejores prácticas del sector.",
    },
  ]

  return (
    <section className="py-20 bg-white" id="about">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Sobre mí</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Columna Izquierda: Presentación y Skills */}
          <div className="space-y-8 animate-fade-in-left">
            <div className="prose prose-lg text-gray-600">
              <p className="leading-relaxed">
                Soy un desarrollador apasionado por transformar ideas complejas en experiencias digitales elegantes y
                funcionales. Con un fuerte enfoque en el ecosistema{" "}
                <span className="font-semibold text-indigo-600">Laravel</span> y{" "}
                <span className="font-semibold text-indigo-600">React</span>, disfruto creando arquitecturas limpias y
                mantenibles. Me motiva el desafío constante de optimizar el rendimiento y la usabilidad en cada proyecto
                que abordo.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Habilidades Personales</h3>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-indigo-50 hover:text-indigo-700 transition-colors duration-300 cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Columna Derecha: Timeline */}
          <div className="bg-gray-50 p-8 rounded-2xl shadow-sm border border-gray-100 animate-fade-in-right">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <svg className="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                ></path>
              </svg>
              Mi Trayectoria
            </h3>

            <div className="relative pl-8 border-l-2 border-indigo-200 space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="relative">
                  {/* Dot */}
                  <div className="absolute -left-[41px] top-0 w-6 h-6 bg-white border-4 border-indigo-600 rounded-full"></div>

                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-1">
                    <h4 className="text-lg font-bold text-gray-900">{milestone.title}</h4>
                    <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full mt-1 sm:mt-0 w-fit">
                      {milestone.year}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{milestone.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

const SkillCategory = ({ title, icon: Icon, skills, colorClass }: any) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300 hover:-translate-y-1 group">
    <div className="flex items-center gap-3 mb-6">
      <div className={`p-3 rounded-xl ${colorClass} group-hover:scale-110 transition-transform duration-300`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-800">{title}</h3>
    </div>

    <div className="flex flex-wrap gap-2">
      {skills.map((skill: string, index: number) => (
        <span
          key={index}
          className="px-3 py-1.5 bg-gray-50 text-gray-600 text-sm font-medium rounded-lg border border-gray-100 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-colors duration-200 cursor-default select-none"
        >
          {skill}
        </span>
      ))}
    </div>
  </div>
)

function TechSkills() {
  const categories = [
    {
      title: "Frontend Development",
      icon: Layout,
      colorClass: "bg-gradient-to-br from-blue-500 to-cyan-400",
      skills: ["React", "Vite", "Tailwind CSS", "JavaScript (ES6+)", "HTML5", "CSS3"],
    },
    {
      title: "Backend Development",
      icon: Server,
      colorClass: "bg-gradient-to-br from-red-500 to-orange-400",
      skills: ["Laravel", "PHP 8+", "Node.js", "RESTful APIs", "Express"],
    },
    {
      title: "Database & Architecture",
      icon: Database,
      colorClass: "bg-gradient-to-br from-emerald-500 to-teal-400",
      skills: ["MySQL", "PostgreSQL", "Eloquent ORM", "Database Design"],
    },
    {
      title: "DevOps & Tools",
      icon: Terminal,
      colorClass: "bg-gradient-to-br from-slate-700 to-slate-500",
      skills: ["Git", "GitHub", "Docker", "Linux (Bash)", "Composer", "NPM/Yarn"],
    },
  ]

  return (
    <section className="py-20 bg-gray-50" id="skills">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Arsenal Tecnológico</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-600 text-lg">
            Un conjunto de herramientas modernas seleccionadas para construir aplicaciones web rápidas, escalables y
            robustas.
          </p>
        </div>

        {/* Grid de Categorías */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {categories.map((category, index) => (
            <SkillCategory key={index} {...category} />
          ))}
        </div>
      </div>
    </section>
  )
}

function Projects() {
  const projects = [
    {
      id: 1,
      title: "E-Commerce Dashboard",
      description:
        "Panel de administración completo para tiendas online. Permite gestión de inventario, pedidos y análisis de ventas en tiempo real con gráficos interactivos.",
      image: "/placeholder.svg?key=7j7vx",
      tags: ["Laravel", "React", "Inertia", "Tailwind"],
      demoUrl: "#",
      codeUrl: "#",
    },
    {
      id: 2,
      title: "Task Management App",
      description:
        "Aplicación colaborativa para gestión de tareas tipo Kanban. Incluye autenticación de usuarios, actualizaciones en tiempo real y asignación de roles.",
      image: "/placeholder.svg?key=qm4tk",
      tags: ["React", "Vite", "Firebase", "Redux"],
      demoUrl: "#",
      codeUrl: "#",
    },
    {
      id: 3,
      title: "Real Estate Platform",
      description:
        "Plataforma de bienes raíces con búsqueda avanzada, mapas interactivos y sistema de citas para visitas. Optimizada para SEO y velocidad.",
      image: "/placeholder.svg?key=hh54u",
      tags: ["Laravel", "MySQL", "Vue.js", "Bootstrap"],
      demoUrl: "#",
      codeUrl: "#",
    },
  ]

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Proyectos Destacados</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Una selección de mis trabajos más recientes, demostrando mis capacidades en desarrollo Full Stack.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              className="group bg-white rounded-xl overflow-hidden shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]"
            >
              {/* Project Image */}
              <div className="relative overflow-hidden h-48 bg-gray-200">
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 flex items-center justify-center">
                  <span className="text-white font-semibold tracking-wider border-2 border-white px-4 py-2 rounded-lg transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    Ver Proyecto
                  </span>
                </div>
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-600 mb-4 line-clamp-3 text-sm leading-relaxed">{project.description}</p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 rounded-full border border-indigo-100"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-4 border-t border-gray-100">
                  <a
                    href={project.demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-md hover:shadow-lg"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver Demo
                  </a>
                  <a
                    href={project.codeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:text-indigo-600 hover:border-indigo-200 transition-all"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Código
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus("loading")
    setErrorMessage("")

    // Simulación de envío para el preview
    setTimeout(() => {
      setStatus("success")
      setFormData({ name: "", email: "", message: "" })
      setTimeout(() => setStatus("idle"), 5000)
    }, 1500)
  }

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Contáctame</h2>
          <div className="w-20 h-1 bg-indigo-600 mx-auto rounded-full mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            ¿Tienes un proyecto en mente o quieres colaborar? Déjame un mensaje y te responderé lo antes posible.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 flex flex-col md:flex-row">
          <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-10 text-white md:w-2/5 flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-6">Hablemos</h3>
              <p className="text-indigo-100 leading-relaxed mb-8">
                Estoy disponible para nuevas oportunidades y colaboraciones. ¡No dudes en contactarme!
              </p>
            </div>

            <div className="space-y-6 text-indigo-100">
              <div className="flex items-center space-x-4">
                <div className="bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <span>tu.email@ejemplo.com</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <span>Ciudad, País</span>
              </div>
            </div>
          </div>

          <div className="p-10 md:w-3/5">
            {status === "success" ? (
              <div className="h-full flex flex-col items-center justify-center text-center animate-fade-in-up">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">¡Mensaje Enviado!</h3>
                <p className="text-gray-600">Gracias por contactarme. Te responderé a la brevedad.</p>
                <button
                  onClick={() => setStatus("idle")}
                  className="mt-8 px-6 py-2 text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors"
                >
                  Enviar otro mensaje
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:bg-white transition-all duration-200 outline-none"
                    placeholder="Tu nombre"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:bg-white transition-all duration-200 outline-none"
                    placeholder="ejemplo@correo.com"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Mensaje
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows="4"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 focus:bg-white transition-all duration-200 outline-none resize-none"
                    placeholder="Cuéntame sobre tu proyecto..."
                  ></textarea>
                </div>

                {status === "error" && (
                  <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg text-sm animate-shake">
                    <AlertCircle className="w-4 h-4" />
                    {errorMessage}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={status === "loading"}
                  className="w-full flex items-center justify-center px-8 py-4 text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg font-semibold shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed transform hover:-translate-y-1"
                >
                  {status === "loading" ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin mr-2" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      Enviar Mensaje
                      <Send className="w-5 h-5 ml-2" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Hero Section */}
      <div className="flex-grow flex items-center justify-center px-6 py-20 sm:px-8">
        <div className="max-w-4xl w-full space-y-12 text-center">
          {/* Avatar / Profile Image */}
          <div className="relative mx-auto w-40 h-40 sm:w-48 sm:h-48">
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 blur-lg opacity-75 animate-pulse"></div>
            <img
              className="relative w-full h-full rounded-full object-cover border-4 border-white shadow-xl transition-transform duration-300 hover:scale-105"
              src="/placeholder.svg?key=0dwcm"
              alt="Avatar"
            />
          </div>

          {/* Hero Content */}
          <div className="space-y-6">
            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-gray-900 animate-fade-in-down">
              Hola, soy{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Tu Nombre
              </span>
            </h1>

            <h2 className="text-xl sm:text-2xl font-medium text-gray-600 animate-fade-in-up delay-100">
              Full Stack Developer | Laravel & React
            </h2>

            <p className="max-w-2xl mx-auto text-lg text-gray-500 leading-relaxed animate-fade-in-up delay-200">
              Construyo soluciones web robustas y escalables. Especializado en crear experiencias de usuario fluidas con
              React integradas perfectamente en backends de Laravel.
            </p>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in-up delay-300">
            <a
              href="#about"
              className="inline-flex items-center px-8 py-3 rounded-full text-white bg-indigo-600 hover:bg-indigo-700 font-semibold shadow-lg transition-all hover:-translate-y-1 hover:shadow-indigo-500/30"
            >
              <ArrowDown className="w-5 h-5 mr-2" />
              Conóceme más
            </a>

            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-3 rounded-full text-gray-700 bg-white border border-gray-200 hover:border-indigo-500 hover:text-indigo-600 font-semibold shadow-sm transition-all hover:-translate-y-1"
            >
              <Linkedin className="w-5 h-5 mr-2" />
              LinkedIn
            </a>

            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-3 rounded-full text-gray-700 bg-white border border-gray-200 hover:border-gray-900 hover:text-gray-900 font-semibold shadow-sm transition-all hover:-translate-y-1"
            >
              <Github className="w-5 h-5 mr-2" />
              GitHub
            </a>
          </div>
        </div>
      </div>

      {/* Insertamos la nueva sección AboutMe debajo del Hero */}
      <AboutMe />

      <TechSkills />

      {/* Insertamos la nueva sección Projects debajo de TechSkills */}
      <Projects />

      {/* Insertamos la nueva sección ContactForm debajo de Projects */}
      <ContactForm />

      {/* Estilos personalizados para animaciones */}
      <style>{`
        @keyframes fade-in-down {
          0% { opacity: 0; transform: translateY(-20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes fade-in-up {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes fade-in-left {
          0% { opacity: 0; transform: translateX(-20px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        @keyframes fade-in-right {
          0% { opacity: 0; transform: translateX(20px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        .animate-fade-in-down {
          animation: fade-in-down 0.8s ease-out forwards;
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
        .animate-fade-in-left {
          animation: fade-in-left 0.8s ease-out forwards;
        }
        .animate-fade-in-right {
          animation: fade-in-right 0.8s ease-out forwards;
        }
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
          20%, 40%, 60%, 80% { transform: translateX(10px); }
        }
        .animate-shake {
          animation: shake 0.8s cubic-bezier(.36,.07,.19,.97) infinite;
        }
      `}</style>
    </div>
  )
}
