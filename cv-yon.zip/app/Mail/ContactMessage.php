<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ContactMessage extends Mailable
{
    use Queueable, SerializesModels;

    public $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Nuevo Mensaje de Contacto - Portafolio',
            from: $this->data['email'], // Opcional: usar el email del remitente
        );
    }

    public function content(): Content
    {
        // Puedes usar una vista blade 'emails.contact' o texto plano
        return new Content(
            view: 'emails.contact', // Asegúrate de crear resources/views/emails/contact.blade.php
            with: [
                'name' => $this->data['name'],
                'email' => $this->data['email'],
                'messageContent' => $this->data['message'],
            ],
        );
    }
}
